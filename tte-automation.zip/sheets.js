const { google } = require('googleapis');
const { v4: uuidv4 } = require('uuid');

// Load .env jika ada (lokal), tidak akan menimpa variable yang sudah ada (Railway)
require('dotenv').config();

// Baca credentials dari environment variable (Railway)
// atau dari file lokal (komputer lokal)
let auth;
console.log('GOOGLE_CREDENTIALS:', process.env.GOOGLE_CREDENTIALS ? 'ADA' : 'TIDAK ADA');
if (process.env.GOOGLE_CREDENTIALS) {
    const credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
    auth = new google.auth.GoogleAuth({
        credentials,
        scopes: ['https://www.googleapis.com/auth/spreadsheets']
    });
} else {
    auth = new google.auth.GoogleAuth({
        keyFile: 'service-account.json',
        scopes: ['https://www.googleapis.com/auth/spreadsheets']
    });
}

const SPREADSHEET_ID = '1sOWTiTA2RjiWbl8UuRw8D-p_tqEsy8LrHXmrDRquYDY';
const SHEET_NAME = 'QUEUE_NEW';

/*
 * STRUKTUR KOLOM QUEUE_NEW (A–O):
 * A  → ID
 * B  → Nama Dokumen
 * C  → Pemaraf
 * D  → Penandatangan 1      E  → Anchor 1
 * F  → Penandatangan 2      G  → Anchor 2
 * H  → Penandatangan 3      I  → Anchor 3
 * J  → Penandatangan 4      K  → Anchor 4
 * L  → Tahun
 * M  → Link File Lokal
 * N  → Status
 * O  → Chat ID Telegram (untuk notifikasi balik)
 */

async function readRows() {
    try {
        const authClient = await auth.getClient();
        const sheets = google.sheets({ version: 'v4', auth: authClient });

        const res = await sheets.spreadsheets.values.get({
            spreadsheetId: SPREADSHEET_ID,
            range: `${SHEET_NAME}!A2:O`
        });

        const rows = res.data.values || [];

        return rows.map((row, index) => ({
            row: index + 2,
            id: row[0] || '',
            nama: row[1] || '',
            pemaraf: row[2] || '',
            penandatangan1: row[3] || '',
            anchor1: row[4] || '',
            penandatangan2: row[5] || '',
            anchor2: row[6] || '',
            penandatangan3: row[7] || '',
            anchor3: row[8] || '',
            penandatangan4: row[9] || '',
            anchor4: row[10] || '',
            tahun: Number(row[11] || 0),
            linkFileLocal: row[12] || '',
            status: row[13] || '',
            chatId: row[14] || ''   // O — Chat ID Telegram
        }));

    } catch (err) {
        console.error('❌ Gagal membaca Spreadsheet:', err.message);
        return [];
    }
}

async function appendRow(item) {
    try {
        const authClient = await auth.getClient();
        const sheets = google.sheets({ version: 'v4', auth: authClient });

        await sheets.spreadsheets.values.append({
            spreadsheetId: SPREADSHEET_ID,
            range: `${SHEET_NAME}!A:O`,
            valueInputOption: 'RAW',
            requestBody: {
                values: [[
                    uuidv4(),             // A — ID
                    item.namaDokumen,     // B
                    item.pemaraf,         // C
                    item.penandatangan1,  // D
                    item.anchor1,         // E
                    item.penandatangan2,  // F
                    item.anchor2,         // G
                    item.penandatangan3,  // H
                    item.anchor3,         // I
                    item.penandatangan4,  // J
                    item.anchor4,         // K
                    item.tahun,           // L
                    item.linkFileLocal,   // M
                    '',                   // N — Status kosong
                    item.chatId           // O — Chat ID Telegram
                ]]
            }
        });

        console.log(`📝 Dokumen '${item.namaDokumen}' ditambahkan ke QUEUE_NEW`);

    } catch (err) {
        console.error('❌ Gagal append ke Spreadsheet:', err.message);
        throw err;
    }
}

async function updateStatus(rowNumber, status) {
    try {
        const authClient = await auth.getClient();
        const sheets = google.sheets({ version: 'v4', auth: authClient });

        await sheets.spreadsheets.values.update({
            spreadsheetId: SPREADSHEET_ID,
            range: `${SHEET_NAME}!N${rowNumber}`,
            valueInputOption: 'RAW',
            requestBody: { values: [[status]] }
        });

        console.log(`📝 Baris ${rowNumber} updated → ${status}`);

    } catch (err) {
        console.error(`❌ Gagal update baris ${rowNumber}:`, err.message);
    }
}

module.exports = { readRows, appendRow, updateStatus };